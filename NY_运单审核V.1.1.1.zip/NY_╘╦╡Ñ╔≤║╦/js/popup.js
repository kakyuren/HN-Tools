// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';
var vurl='https://ny-gateway.chngdz.com/platform/cert_truck/list?size=20&page=1&certStatus=authenticating';

$(document).ready(function(){

    function test(){
        alert("ok")
    }


});

