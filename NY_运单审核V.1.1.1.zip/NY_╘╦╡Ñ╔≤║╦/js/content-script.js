


	$(function(){
	//	$(document).on("contextmenu",function(e){ 
	//		return false; 
	//	}); 
		var url="https://ny-gateway.chngdz.com/waybill/waybill/outsourcing_list?size=1&page=1&waybillNo=";
		var allcontents=[];
		var imgurl="https://ny-img.chngdz.com/";
		var allcontents;


		

		$("#submit").click(function(){
			$("textarea").css("display","none");
			$(this).css("display","none");
			var list=[];
			list=$("#trafficid").val().split("\n");
			for(i=0;i<list.length;i++){
				$("#result").append("<div><a href='#' value="+list[i]+">"+list[i]+"</a></div>");
			}
			//$.each(list,function(i,val){
			//	$("#result").append("<div><a href='#' value="+val+">"+val+"</a></div>");
		//}
		//)

		});



	function addloadImg(loadattachment) {
		$(".img").removeAttr("src");
		var im=1;
		newurl=loadattachment.split(":");
		$.each(newurl,function(i,j){
			imgget="https://ny-gateway.chngdz.com/waybill/fw/image/"+j+"/get";
			$.getJSON(imgget, function (res){
				if(res){
					$.each(res,function(i,field){
						if(i=='content'){
							allcontents=field["thumbnailList"];
							var imgurl1=allcontents[0]['url'];
							//$("#load").removeAttr("src");
							//alert(imgurl);
							$('#load'+im).remove("src");
							$('#load'+im).attr("src",imgurl1);
							$('#load'+im).parent("li").css("display","");
							im++;

							//$('#load'+num).attr("src",imgurl);
						}
					})
				}
			});
		})

   }


	function addunloadImg(unloadattachment) {
		var iz=1;
		newurl=unloadattachment.split(":");
		$.each(newurl,function(i,j){
			imgget="https://ny-gateway.chngdz.com/waybill/fw/image/"+j+"/get";
			$.getJSON(imgget, function (res){
				if(res){
					$.each(res,function(i,field){
						if(i=='content'){
							allcontents=field["thumbnailList"];
							var imgurl2=allcontents[0]['url'];
	
							$('#unload'+iz).remove("src");
							$('#unload'+iz).attr("src",imgurl2);
							$('#unload'+iz).parent("li").css("display","");
							iz++;
						}
					})
				}
			});
		})

   }

   function viewp(){

	var $images = $('#tupian');

	$images.viewer({
		//inline: true,
		//viewed: function() {
		//	$image.viewer.hide();
		toolbar:{
			rotateLeft:{
				show:4,
				size:'large'
			},
			rotateRight:{
				show:4,
				size:'large'
			}
		}

	});
}

		
$('body').on('mousedown','a',function(e){ 



	
	if( e.which== 1 ) { 
		$("#info").empty();
		$(this).css({"background-color":"#15fd84","font-weight":"bold","color":"white"});
		exp=$(this).attr('value'); 
		newurl=url+exp;
		$.getJSON(newurl, function (res){
			if(res){
				$.each(res,function(i,field){
					if(i=='content'){
						allcontents=field[0];
					}
				})
			}
		});


			if(allcontents.waybillNo==exp)
			{
				var infocontents=[
					"运单号: "+allcontents.waybillNo,
					"发货时间: "+allcontents.loadingTime,
					"收货时间： "+allcontents.loadingInputTime,
					"发货重量: 	"+allcontents.loadingGoodsWeight,
					"收货重量: 	"+allcontents.unloadingGoodsWeight,
					"车牌号:	"+allcontents.truckLicenseNo,
		
				];

				for(ix in infocontents){
					$("#info").append("<div>"+infocontents[ix]+"</div>")
				}
				$("#img").css("display",'');
				addloadImg(allcontents.loadingAttachment);
				addunloadImg(allcontents.unloadingAttachment);
				viewp();


			}
	} else{
		if(e.which==3){
			$(this).css({"background-color":"#bb361b","font-weight":"lighter","color":"black"});
		}
	}
	//return true; 
	})






}
);
