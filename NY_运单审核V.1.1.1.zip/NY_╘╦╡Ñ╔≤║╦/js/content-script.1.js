


	$(function(){
		$(document).on("contextmenu",function(e){ 
			return false; 
		}); 
		var url="https://ny-gateway.chngdz.com/waybill/waybill/outsourcing_list?size=1&page=1&waybillNo=";
		var allcontents=[];
		var imgurl="https://ny-img.chngdz.com/";
		var allcontents;


		

		$("#submit").click(function(){
			$("textarea").css("display","none");
			var list=[];
			list=$("#trafficid").val().split("\n");
			for(i=0;i<list.length;i++){
				$("#result").append("<div><a href='#' value="+list[i]+">"+list[i]+"</a></div>");
			}
			//$.each(list,function(i,val){
			//	$("#result").append("<div><a href='#' value="+val+">"+val+"</a></div>");
		//}
		//)

	});


	function CheckImgExists(imgurl) {
		var ImgObj = new Image(); //判断图片是否存在  
		ImgObj.src = imgurl;  
		//存在图片
		if (ImgObj.fileSize > 0 || (ImgObj.width > 0 && ImgObj.height > 0)) {  
			 return true;
		} else {  
			 return false;
		 }   
   }

   function splitImgURL(imgurl){
		var attachment=imgurl.split(":");
		for(i=0;i<attachment.length;i++){
			//alert(attachment[i])
		}

   }

		
$('body').on('mousedown','a',function(e){ 



	
	if( e.which== 1 ) { 
		$("#info").empty();
		$(this).css({"background-color":"#15fd84","font-weight":"bold","color":"white"});
		exp=$(this).attr('value'); 
		newurl=url+exp;
		$.getJSON(newurl, function (res){
			if(res){
				$.each(res,function(i,field){
					if(i=='content'){
						allcontents=field[0];
					}
				})
			}
		});


			if(allcontents.waybillNo==exp)
			{
				var infocontents=[
					"运单号: "+allcontents.waybillNo,
					"发货时间: "+allcontents.loadingTime,
					"收货时间： "+allcontents.loadingInputTime,
					"发货重量: 	"+allcontents.loadingGoodsWeight,
					"收货重量: 	"+allcontents.unloadingGoodsWeight,
					"车牌号:	"+allcontents.truckLicenseNo,
		
				];
				for(ix in infocontents){
					$("#info").append("<div>"+infocontents[ix]+"</div>")
				}
				var $images = $('#images');
				imgload=imgurl+allcontents.loadingAttachment+".jpg";
				if(CheckImgExists(imgload)==false)
				{
					imgload=imgurl+allcontents.loadingAttachment+".png"
				};
				imgunload=imgurl+allcontents.unloadingAttachment+".jpg";
				//splitImgURL(allcontents.unloadingAttachment);
				if(CheckImgExists(imgunload)==false)
				{
					imgunload=imgurl+allcontents.unloadingAttachment+".png";
				};
				$("#img").css("display",'');
				
				$("#load").removeAttr("src");
				$("#load").attr("src",imgload);
				$("#unload").removeAttr("src");
				$("#unload").attr("src",imgunload);



				$images.viewer({
					//inline: true,
					//viewed: function() {
					//	$image.viewer.hide();
					toolbar:{
						rotateLeft:{
							show:4,
							size:'large'
						},
						rotateRight:{
							show:4,
							size:'large'
						}
					}
					 // }
				});


			}
	} else{
		if(e.which==3){
			$(this).css({"background-color":"#bb361b","font-weight":"lighter","color":"black"});
		}
	}
	//return true; 
	})





}
);
