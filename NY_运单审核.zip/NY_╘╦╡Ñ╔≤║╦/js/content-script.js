

/*--$(function(){
    $("#pageRefresh").click(function(){
        $(this).style.font="italic bold 12px arial,serif";
        });
    });--*/
	
	$(function(){
		$(document).on("contextmenu",function(e){ 
			return false; 
		}); 
		var size=1;
		var url="https://ny-gateway.chngdz.com/waybill/waybill/outsourcing_list?size="+size+"&page=1&logisticsNo=";
		var allcontents=[];
		var imgurl="https://ny-img.chngdz.com/";

		

		$("#submit").click(function(){
			$(this).css("display","none");
			newurl=url+$("#orderid").val()
			$.getJSON(newurl, function (res){
				if(res){
					$.each(res,function(i,field){
						if(i=="total"){
						size=field;
						newurl="https://ny-gateway.chngdz.com/waybill/waybill/outsourcing_list?size="+size+"&page=1&logisticsNo="+$("#orderid").val();
						$.getJSON(newurl, function (res){
							if(res){
								var c=0;
								$.each(res,function(i,field){
									if(i=="content"){
										$("#listno").text("待审核运单列表  "+size+"个");
										$.each(res.content,function(i,field){
										$("#result").append("<div><a href='#' value="+field.waybillNo+">"+field.waybillNo+"</a></div>");
										allcontents.push(field);
									}
									)
								}}
								
								)}
						})


					   // return vnumber
						};
					});
			}
		}

		


	
	)
}
);



$('body').on('mousedown','a',function(e){ 
	if( e.which== 1 ) { 
		$("#info").empty();
		$(this).css({"background-color":"#15fd84","font-weight":"bold","color":"white"});
		exp=$(this).attr('value'); 
		var $images = $('#images');
		//alert(exp);
		//actual=allcontents.waybillNo;
		//alert(actual);
		//for(i in allcontents){
		//	$("#info").append("<div class='divcss_info'>"+i+":"+allcontents[i]+"</div>")
		//}
		for(i in allcontents){
			if(allcontents[i].waybillNo==exp)
			{
				var infocontents=[
					"运单号: "+allcontents[i].waybillNo,
					"发货时间: "+allcontents[i].loadingTime,
					"收货时间： "+allcontents[i].loadingInputTime,
					"发货重量: 	"+allcontents[i].loadingGoodsWeight,
					"收货重量: 	"+allcontents[i].unloadingGoodsWeight,
					"车牌号:	"+allcontents[i].truckLicenseNo,
		
				];
				for(ix in infocontents){
					$("#info").append("<div>"+infocontents[ix]+"</div>")
				}
				imgload=imgurl+allcontents[i].loadingAttachment+".jpg";
				imgunload=imgurl+allcontents[i].unloadingAttachment+".jpg";
				$("#img").css("display",'');
				$("#load").removeAttr("src");
				$("#load").attr("src",imgload);
				$("#unload").removeAttr("src");
				$("#unload").attr("src",imgunload);
				$images.viewer({
					//inline: true,
					//viewed: function() {
					//	$image.viewer.hide();
					 // }
			});


			}
		}
	} else{
		if(e.which==3){
			$(this).css({"background-color":"#bb361b","font-weight":"lighter","color":"black"});
		}
	}
	//return true; 
	})





}
);
